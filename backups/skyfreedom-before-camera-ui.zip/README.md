# SkyFreedom

Lokalny demonstrator procesu, w którym obserwacja z drona staje się sprawdzonym ostrzeżeniem dla jednostki terenowej.

## Uruchomienie

Uruchom lokalny serwer w folderze projektu, np. `python -m http.server 8765`, a następnie otwórz `http://localhost:8765`. Strona używa statycznego HTML, CSS i JavaScript; nie wymaga konta ani backendu. Fonty pobierają się z Google Fonts, a fonty zastępcze działają bez sieci. Widok 2D mapy działa lokalnie. Pierwsze otwarcie widoku 3D pobiera bibliotekę Three.js z jsDelivr; w razie braku sieci zostaje uproszczony widok zastępczy, a mapa 2D pozostaje dostępna.

## Przepływ pokazu

1. Wybierz widok dowódcy, operatora drona lub jednostki terenowej.
2. W widoku operatora uruchom symulację i zgłoś obserwację.
3. W widoku dowódcy potwierdź zgłoszenie, a następnie przekaż alert zespołom.
4. W widoku jednostki terenowej sprawdź zalecenie. Wróć do dowódcy, aby zamknąć zdarzenie.
5. „Reset pokazu” czyści zdarzenie i przywraca wartości początkowe.

Przycisk „Zasymuluj zgłoszenie z drona” pozwala szybko pokazać drogę zgłoszenia i weryfikacji bez przechodzenia do widoku operatora.

## Granice demonstratora

Pozycje, mapa 2D, teren 3D, obserwacja, łączność i telemetria są poglądowe. Mapa nie pobiera zewnętrznych kafli ani prawdziwych współrzędnych; model terenu powstaje proceduralnie w przeglądarce. Aplikacja nie łączy się z dronem, systemem lotniczym ani służbami i nie zastępuje procedur lub wymaganych zgód.

## Projekt

- `PRODUCT.md` — potwierdzone fakty o produkcie i granice prototypu.
- `UX_RESEARCH.md` — hipotezy ról, przepływ i heurystyczny audyt interfejsu.
- `DESIGN.md` — wybrany kierunek wizualny i zasady interfejsu.
- `map-experience.css` / `animations.css` — mapa 2D/3D i animacje stanów.
- `terrain-scene.js` — proceduralny podgląd terenu w Three.js, bez zewnętrznych map ani modeli.
