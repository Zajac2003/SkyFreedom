import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.186.0/build/three.module.js';

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

export function mountTerrainScene(canvas) {
  const host = canvas.parentElement;
  const renderer = new THREE.WebGLRenderer({ canvas, alpha: false, antialias: true, powerPreference: 'low-power' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setClearColor(0x91aa9e, 1);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x91aa9e);
  scene.fog = new THREE.Fog(0x91aa9e, 32, 74);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 120);
  const target = new THREE.Vector3(0, 0, 0);
  let yaw = 0.72;
  let pitch = 0.56;
  let distance = 27;
  let isActive = false;
  let isFlying = false;
  let frameId = 0;
  let introStartedAt = 0;
  let lastFrame = 0;
  let dragPoint = null;
  let isVisible = false;
  let disposed = false;

  const hemi = new THREE.HemisphereLight(0xf3f3e7, 0x42615b, 2.1);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff0d3, 3.2);
  sun.position.set(-9, 20, 12);
  sun.castShadow = true;
  sun.shadow.mapSize.set(768, 768);
  sun.shadow.camera.left = -25;
  sun.shadow.camera.right = 25;
  sun.shadow.camera.top = 25;
  sun.shadow.camera.bottom = -25;
  sun.shadow.bias = -0.00018;
  scene.add(sun);

  function heightAt(x, z) {
    const ridgeA = Math.exp(-((x + 6) ** 2 / 85 + (z - 1) ** 2 / 36)) * 2.25;
    const ridgeB = Math.exp(-((x - 10) ** 2 / 52 + (z + 8) ** 2 / 25)) * 1.55;
    return ridgeA + ridgeB + Math.sin(x * 0.23 + z * 0.08) * 0.28 + Math.cos(z * 0.27 - x * 0.09) * 0.22;
  }

  const terrainGeometry = new THREE.PlaneGeometry(44, 34, 100, 78);
  terrainGeometry.rotateX(-Math.PI / 2);
  const positions = terrainGeometry.attributes.position;
  const terrainColors = [];
  const lowland = new THREE.Color(0x809d7a);
  const upland = new THREE.Color(0x59745f);
  const meadow = new THREE.Color(0xa5b58a);
  for (let i = 0; i < positions.count; i += 1) {
    const x = positions.getX(i);
    const z = positions.getZ(i);
    const y = heightAt(x, z);
    positions.setY(i, y);
    const shade = lowland.clone().lerp(upland, THREE.MathUtils.clamp((y + 0.2) / 3.8, 0, 0.62));
    if (y < 0.34) shade.lerp(meadow, 0.21);
    terrainColors.push(shade.r, shade.g, shade.b);
  }
  terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(terrainColors, 3));
  terrainGeometry.computeVertexNormals();
  const terrain = new THREE.Mesh(terrainGeometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0 }));
  terrain.receiveShadow = true;
  scene.add(terrain);

  function ribbon(points, width, material, lift = 0.045, segments = 110) {
    const curve = new THREE.CatmullRomCurve3(points.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z) + lift, z)));
    const verts = [];
    const indices = [];
    for (let i = 0; i <= segments; i += 1) {
      const t = i / segments;
      const point = curve.getPoint(t);
      const tangent = curve.getTangent(t).setY(0).normalize();
      const side = new THREE.Vector3(-tangent.z, 0, tangent.x).multiplyScalar(width / 2);
      const ground = heightAt(point.x, point.z) + lift;
      verts.push(point.x + side.x, ground, point.z + side.z, point.x - side.x, ground, point.z - side.z);
      if (i < segments) {
        const k = i * 2;
        indices.push(k, k + 1, k + 2, k + 1, k + 3, k + 2);
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry, material);
    mesh.receiveShadow = true;
    scene.add(mesh);
    return mesh;
  }

  const riverPoints = [[-22, -13], [-15, -8], [-10, -3], [-5, -1], [1, 3], [8, 8], [15, 10], [23, 13]];
  const riverCurve = new THREE.CatmullRomCurve3(riverPoints.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z) - 0.2, z)));
  const river = new THREE.Mesh(new THREE.TubeGeometry(riverCurve, 120, 0.72, 10, false), new THREE.MeshStandardMaterial({ color: 0x60a5a0, roughness: 0.34, metalness: 0.06, transparent: true, opacity: 0.94 }));
  river.receiveShadow = true;
  scene.add(river);
  const riverGlint = new THREE.Mesh(new THREE.TubeGeometry(riverCurve, 120, 0.2, 8, false), new THREE.MeshBasicMaterial({ color: 0xb6dfd2, transparent: true, opacity: 0.35 }));
  riverGlint.position.y = 0.08;
  scene.add(riverGlint);

  const roadCasing = new THREE.MeshStandardMaterial({ color: 0x6e7773, roughness: 0.88 });
  const roadSurface = new THREE.MeshStandardMaterial({ color: 0xe5deca, roughness: 0.83 });
  const routeMaterial = new THREE.MeshStandardMaterial({ color: 0x157c6c, roughness: 0.48, emissive: 0x104c43, emissiveIntensity: 0.24 });
  const mainRoad = [[-24, -4], [-15, -3], [-7, -1], [0, 2], [9, 1], [17, -2], [24, -1]];
  const northRoad = [[-14, -18], [-12, -10], [-10, -3], [-11, 5], [-14, 13], [-13, 19]];
  const easternRoad = [[4, -18], [3, -11], [6, -4], [9, 2], [13, 9], [18, 17]];
  ribbon(mainRoad, 0.78, roadCasing, 0.08);
  ribbon(mainRoad, 0.63, roadSurface, 0.1);
  ribbon(northRoad, 0.55, roadCasing, 0.08);
  ribbon(northRoad, 0.43, roadSurface, 0.1);
  ribbon(easternRoad, 0.48, roadCasing, 0.08);
  ribbon(easternRoad, 0.37, roadSurface, 0.1);

  const pathPoints = [[-8, 4], [-4, 2], [0, 0], [5, -3], [9, -6]];
  const routeCurve = new THREE.CatmullRomCurve3(pathPoints.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z) + 0.18, z)));
  const routePath = new THREE.Mesh(new THREE.TubeGeometry(routeCurve, 48, 0.075, 7, false), routeMaterial);
  scene.add(routePath);

  const treeTrunk = new THREE.MeshStandardMaterial({ color: 0x695740, roughness: 1 });
  const canopyMaterials = [0x375f4d, 0x4f7559, 0x69845d].map((color) => new THREE.MeshStandardMaterial({ color, roughness: 0.94 }));
  const trunkGeometry = new THREE.CylinderGeometry(0.045, 0.07, 0.4, 6);
  const coneGeometries = [new THREE.ConeGeometry(0.42, 0.92, 7), new THREE.ConeGeometry(0.32, 0.72, 7)];
  const trees = new THREE.Group();
  let seed = 73;
  const rand = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  for (let i = 0; i < 46; i += 1) {
    const x = (rand() - 0.5) * 39;
    const z = (rand() - 0.5) * 27;
    if (Math.abs(z - (0.44 * x + 1.8)) < 1.25 || (x > -14 && x < 13 && z > -4 && z < 4)) continue;
    const trunk = new THREE.Mesh(trunkGeometry, treeTrunk);
    const y = heightAt(x, z);
    trunk.position.set(x, y + 0.2, z);
    trunk.castShadow = true;
    trees.add(trunk);
    for (let tier = 0; tier < 2; tier += 1) {
      const crown = new THREE.Mesh(coneGeometries[tier], canopyMaterials[Math.floor(rand() * canopyMaterials.length)]);
      crown.position.set(x, y + 0.55 + tier * 0.34, z);
      crown.castShadow = true;
      trees.add(crown);
    }
  }
  scene.add(trees);

  const blocks = new THREE.Group();
  const buildingMaterials = [0xb9c1b2, 0xc7c7ba, 0xb2bcb4].map((color) => new THREE.MeshStandardMaterial({ color, roughness: 0.9 }));
  for (const [cx, cz] of [[-18, 4], [-17, 8], [-17, 12], [16, -10], [19, -9], [18, -13], [2, 12], [5, 13]]) {
    for (let row = 0; row < 3; row += 1) for (let col = 0; col < 3; col += 1) {
      const w = 0.8 + rand() * 0.6;
      const d = 0.65 + rand() * 0.5;
      const h = 0.28 + rand() * 0.8;
      const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), buildingMaterials[Math.floor(rand() * buildingMaterials.length)]);
      const x = cx + col * 1.4;
      const z = cz + row * 1.25;
      building.position.set(x, heightAt(x, z) + h / 2 + 0.04, z);
      building.rotation.y = (rand() - 0.5) * 0.2;
      building.castShadow = true;
      building.receiveShadow = true;
      blocks.add(building);
    }
  }
  scene.add(blocks);

  const drone = new THREE.Group();
  const hull = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.2, 0.74), new THREE.MeshStandardMaterial({ color: 0xf4f4e9, roughness: 0.43, metalness: 0.24 }));
  hull.castShadow = true;
  drone.add(hull);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 8), new THREE.MeshStandardMaterial({ color: 0x174d47, roughness: 0.35, metalness: 0.25 }));
  nose.position.set(0, -0.02, 0.39);
  drone.add(nose);
  const armMaterial = new THREE.MeshStandardMaterial({ color: 0x283b3b, metalness: 0.48, roughness: 0.5 });
  const rotorMaterial = new THREE.MeshStandardMaterial({ color: 0xdde8db, metalness: 0.3, roughness: 0.3 });
  const rotors = [];
  for (const [x, z] of [[-0.65, -0.65], [0.65, -0.65], [-0.65, 0.65], [0.65, 0.65]]) {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.1, 6), armMaterial);
    arm.rotation.z = Math.PI / 2;
    arm.rotation.y = Math.atan2(z, x);
    arm.scale.set(0.45, 1, 1);
    arm.position.set(x * 0.42, 0, z * 0.42);
    drone.add(arm);
    const rotorGroup = new THREE.Group();
    rotorGroup.position.set(x, 0.1, z);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.12, 8), armMaterial);
    rotorGroup.add(stem);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.025, 0.1), rotorMaterial);
    blade.position.y = 0.08;
    rotorGroup.add(blade);
    const crossBlade = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.025, 0.68), rotorMaterial);
    crossBlade.position.y = 0.08;
    rotorGroup.add(crossBlade);
    drone.add(rotorGroup);
    rotors.push(rotorGroup);
  }
  const beacon = new THREE.PointLight(0x57e0bd, 1.7, 4);
  beacon.position.set(0, 0.3, 0);
  drone.add(beacon);
  scene.add(drone);

  const vehicle = new THREE.Group();
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.36, 1.55), new THREE.MeshStandardMaterial({ color: 0x496b76, roughness: 0.75 }));
  chassis.position.y = 0.35;
  chassis.castShadow = true;
  vehicle.add(chassis);
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.28, 0.56), new THREE.MeshStandardMaterial({ color: 0xd5e4de, roughness: 0.3, metalness: 0.1 }));
  windshield.position.set(0, 0.64, 0.25);
  vehicle.add(windshield);
  const wheelGeometry = new THREE.CylinderGeometry(0.19, 0.19, 0.12, 12);
  const wheelMaterial = new THREE.MeshStandardMaterial({ color: 0x283333, roughness: 1 });
  for (const x of [-0.53, 0.53]) for (const z of [-0.48, 0.48]) {
    const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(x, 0.22, z);
    vehicle.add(wheel);
  }
  const unitX = 8;
  const unitZ = -5;
  vehicle.position.set(unitX, heightAt(unitX, unitZ) + 0.1, unitZ);
  vehicle.rotation.y = -0.4;
  scene.add(vehicle);

  const evac = new THREE.Group();
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.08, 36), new THREE.MeshStandardMaterial({ color: 0xf0e8c9, roughness: 0.8 }));
  const padRing = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.05, 8, 36), new THREE.MeshStandardMaterial({ color: 0x165c52, roughness: 0.6 }));
  padRing.rotation.x = Math.PI / 2;
  padRing.position.y = 0.08;
  evac.add(pad, padRing);
  const crossMat = new THREE.MeshStandardMaterial({ color: 0x165c52, roughness: 0.7 });
  const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.9), crossMat);
  const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.03, 0.12), crossMat);
  crossV.position.y = 0.12;
  crossH.position.y = 0.12;
  evac.add(crossV, crossH);
  const evacX = 15;
  const evacZ = -12;
  evac.position.set(evacX, heightAt(evacX, evacZ) + 0.08, evacZ);
  scene.add(evac);

  const incident = new THREE.Group();
  const warningDisc = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.045, 8, 42), new THREE.MeshStandardMaterial({ color: 0xc55435, emissive: 0x772d1c, emissiveIntensity: 0.36 }));
  warningDisc.rotation.x = Math.PI / 2;
  warningDisc.position.y = 0.12;
  const warningCenter = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.32, 8), new THREE.MeshStandardMaterial({ color: 0xc55435, roughness: 0.52 }));
  warningCenter.position.y = 0.23;
  incident.add(warningDisc, warningCenter);
  incident.position.set(2, heightAt(2, -1) + 0.08, -1);
  scene.add(incident);

  function worldPoint(point) {
    const x = (point.x / 100 - 0.5) * 38;
    const z = (point.y / 100 - 0.5) * 29;
    return new THREE.Vector3(x, heightAt(x, z) + 1.15, z);
  }
  let flightIndex = 0;
  function setDronePosition(point, index = flightIndex) {
    flightIndex = index;
    const next = worldPoint(point);
    drone.position.copy(next);
    const previous = worldPoint({ x: point.x - 2, y: point.y + 1 });
    drone.rotation.y = Math.atan2(next.x - previous.x, next.z - previous.z);
    renderOnce();
  }

  const baseDistance = 27;
  function updateCamera() {
    camera.position.set(
      target.x + Math.sin(yaw) * Math.cos(pitch) * distance,
      target.y + Math.sin(pitch) * distance,
      target.z + Math.cos(yaw) * Math.cos(pitch) * distance,
    );
    camera.lookAt(target);
  }

  function resize() {
    const width = Math.max(1, host.clientWidth);
    const height = Math.max(1, host.clientHeight);
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderOnce();
  }

  function renderOnce() {
    if (disposed || !renderer) return;
    updateCamera();
    renderer.render(scene, camera);
  }

  function animate(now) {
    frameId = 0;
    if (!isActive || !isVisible || document.hidden || disposed || reducedMotion.matches) return;
    const delta = Math.min(0.05, (now - (lastFrame || now)) / 1000);
    lastFrame = now;
    if (!introStartedAt) introStartedAt = now;
    const intro = Math.min(1, (now - introStartedAt) / 1200);
    const eased = 1 - (1 - intro) ** 3;
    distance = baseDistance * (1 - eased) + baseDistance / Math.max(1, 1.22) * eased;
    if (!dragPoint) yaw += delta * (isFlying ? 0.035 : 0.012);
    const rotorSpeed = isFlying ? 18 : 2.4;
    rotors.forEach((rotor, i) => { rotor.rotation.y += delta * rotorSpeed * (i % 2 ? -1 : 1); });
    riverGlint.material.opacity = 0.27 + (Math.sin(now * 0.0012) + 1) * 0.055;
    renderOnce();
    frameId = requestAnimationFrame(animate);
  }

  function startLoop() {
    if (!isActive || !isVisible || document.hidden || reducedMotion.matches || frameId || disposed) return;
    frameId = requestAnimationFrame(animate);
  }
  function setActive(active) {
    isActive = active;
    lastFrame = 0;
    if (active) startLoop();
    else {
      if (frameId) cancelAnimationFrame(frameId);
      frameId = 0;
      renderOnce();
    }
  }
  function setFlight(active) {
    isFlying = active;
    if (isActive) renderOnce();
    startLoop();
  }
  function setZoom(zoom) {
    distance = THREE.MathUtils.clamp(baseDistance / zoom, 15, 34);
    renderOnce();
  }
  function resetView() {
    yaw = 0.72;
    pitch = 0.56;
    distance = baseDistance;
    renderOnce();
  }

  const onPointerDown = (event) => {
    dragPoint = { x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
    canvas.classList.add('is-dragging');
  };
  const onPointerMove = (event) => {
    if (!dragPoint) return;
    const dx = event.clientX - dragPoint.x;
    const dy = event.clientY - dragPoint.y;
    dragPoint = { x: event.clientX, y: event.clientY };
    yaw -= dx * 0.006;
    pitch = THREE.MathUtils.clamp(pitch + dy * 0.004, 0.28, 1.18);
    renderOnce();
  };
  const onPointerUp = () => { dragPoint = null; canvas.classList.remove('is-dragging'); };
  const onWheel = (event) => { event.preventDefault(); distance = THREE.MathUtils.clamp(distance + event.deltaY * 0.014, 14, 36); renderOnce(); };
  const onVisibility = () => { if (document.hidden) { if (frameId) cancelAnimationFrame(frameId); frameId = 0; } else startLoop(); };
  const onMotionChange = () => { if (reducedMotion.matches) { if (frameId) cancelAnimationFrame(frameId); frameId = 0; renderOnce(); } else startLoop(); };
  canvas.addEventListener('pointerdown', onPointerDown);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('pointercancel', onPointerUp);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  document.addEventListener('visibilitychange', onVisibility);
  reducedMotion.addEventListener?.('change', onMotionChange);
  const observer = new ResizeObserver(resize);
  observer.observe(host);
  const visibilityObserver = new IntersectionObserver(([entry]) => {
    isVisible = entry.isIntersecting;
    if (isVisible) { renderOnce(); startLoop(); }
    else if (frameId) { cancelAnimationFrame(frameId); frameId = 0; }
  });
  visibilityObserver.observe(host);
  resize();
  setDronePosition({ x: 31, y: 63 }, 0);

  return {
    setActive,
    setFlight,
    setZoom,
    setDronePosition,
    resetView,
    dispose() {
      disposed = true;
      setActive(false);
      observer.disconnect();
      visibilityObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      reducedMotion.removeEventListener?.('change', onMotionChange);
      canvas.removeEventListener('pointerdown', onPointerDown);
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('pointercancel', onPointerUp);
      canvas.removeEventListener('wheel', onWheel);
      renderer.dispose();
    },
  };
}
