# SkyFreedom visual direction

## Direction

**Karta przekazania** — a warm, clear incident handover that gives every role the same shared situation and makes that role's next action obvious. The role chooser is the first screen. The dashboard puts the operation and map beside a single decision card, and the card changes as an observation is reported, verified, sent, and resolved.

## Visual system

- Canvas `#F2F4ED`; paper surface `#FFFEFA`; deep blue-green ink `#12333B`.
- Teal `#176B5D` signals available actions and confirmed progress; alert clay `#B34224` marks restrictions and hazards; amber marks unverified priority. Every state also has a text label.
- DM Sans carries functional copy; Manrope gives headings a compact, steady operational voice.
- Rounded corners stay between 6 and 14 px. Borders separate controls and work areas; shadows are reserved for temporary overlays and notices.
- Role actions use three plain rows, not a tile grid. The primary workspace uses a situation/map column and one actionable incident column; supporting telemetry and history sit below.
- The local map uses familiar road, park, and water conventions. Its 2D view stays the dependable default; an optional procedural 3D terrain view adds depth without implying geographic accuracy.

## Interaction and accessibility

- The role chooser is a simulation, not an account flow. Changing a role is always available from the top bar.
- Status changes use concise Polish messages; important state also remains in the incident card or history.
- Controls are keyboard reachable with a visible focus ring. Touch controls are at least 44 px tall.
- Map, coordinates, feed, and telemetry are illustrative only. No live aviation or public safety system is connected.
- State changes receive short feedback motion. `prefers-reduced-motion` disables nonessential movement.
- Animate the flight route and incident handover to explain state. Keep the terrain loop local to the visible 3D view and stop it when hidden or reduced motion is requested.

## Approved reference

- `.impeccable/mocks/decision/assigned.png` — selected full-screen concept, “Karta przekazania”.
- Product truth and feature boundary: `PRODUCT.md`.
- Research status, role hypotheses, and heuristic review: `UX_RESEARCH.md`.
