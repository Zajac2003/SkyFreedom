const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const map = $('#map-canvas');
const droneMarker = $('#drone-marker');
const incidentMarker = $('#incident-marker');
const panel = $('#right-panel');
const roleTabs = $$('.role-tab');
const timeline = $('#timeline');
const mapWorld = $('#map-world');
const terrainView = $('#terrain-view');
const mapViewButtons = $$('.map-view-button');

const initialTimeline = [
  { time: '07:39', text: 'Dron 01 rozpoczął rozpoznanie sektora', current: true },
  { time: '07:31', text: 'Jednostka 04 przydzielona do sektora Alfa' },
  { time: '07:18', text: 'Utworzono operację po nawałnicy' },
];

let currentRole = 'commander';
let incidentState = null;
let airspaceRestricted = false;
let simulationOn = false;
let simulationTimer = null;
let telemetryTimer = null;
let toastTimer = null;
let reportOpener = null;
let demoClock = 42;
let terrainScene = null;
let terrainImportPromise = null;
let mapViewMode = '2d';
let mapZoom = 1;
let timelineItems = [...initialTimeline];
const route = [
  { x: 31, y: 63 }, { x: 36, y: 59 }, { x: 40, y: 55 },
  { x: 45, y: 51 }, { x: 50, y: 47 }, { x: 54, y: 44 },
  { x: 59, y: 41 }, { x: 63, y: 37 }, { x: 68, y: 34 },
];
let routeIndex = 0;

function showToast(message) {
  const toast = $('#demo-toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add('hidden'), 2600);
}

function positionDrone(point = route[routeIndex]) {
  const width = mapWorld.clientWidth;
  const height = mapWorld.clientHeight;
  if (!width || !height) return;
  droneMarker.style.setProperty('--drone-x', `${(point.x / 100 * width).toFixed(1)}px`);
  droneMarker.style.setProperty('--drone-y', `${(point.y / 100 * height).toFixed(1)}px`);
  if (mapViewMode === '3d') terrainScene?.setDronePosition(point, routeIndex);
}

function setZoom(nextZoom) {
  mapZoom = Math.max(.85, Math.min(1.65, nextZoom));
  mapWorld.style.setProperty('--map-zoom', mapZoom.toFixed(2));
  mapWorld.classList.add('is-zooming');
  clearTimeout(mapWorld.zoomTimer);
  mapWorld.zoomTimer = setTimeout(() => mapWorld.classList.remove('is-zooming'), 450);
  if (mapViewMode === '3d') terrainScene?.setZoom(mapZoom);
}

async function setMapView(view) {
  mapViewMode = view;
  map.dataset.view = view;
  terrainView.classList.toggle('hidden', view !== '3d');
  mapViewButtons.forEach((button) => {
    const selected = button.dataset.mapView === view;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  if (view === '2d') {
    terrainScene?.setActive(false);
    return;
  }
  terrainView.classList.remove('load-error');
  $('#terrain-status').textContent = simulationOn ? 'Dron porusza się w kierunku alertu' : 'Dron oczekuje na start symulacji';
  if (terrainScene) {
    terrainScene.setDronePosition(route[routeIndex], routeIndex);
    terrainScene.setFlight(simulationOn);
    terrainScene.setZoom(mapZoom);
    terrainScene.setActive(true);
    return;
  }
  terrainView.classList.add('is-loading');
  $('#terrain-status').textContent = 'Przygotowuję model terenu…';
  try {
    terrainImportPromise ??= import('./terrain-scene.js');
    const { mountTerrainScene } = await terrainImportPromise;
    if (mapViewMode !== '3d') {
      terrainView.classList.remove('is-loading');
      return;
    }
    if (!terrainScene) {
      terrainScene = mountTerrainScene($('#terrain-canvas'));
      terrainScene.setDronePosition(route[routeIndex], routeIndex);
      terrainScene.setFlight(simulationOn);
      terrainScene.setZoom(mapZoom);
    }
    terrainView.classList.add('is-ready');
    terrainView.classList.remove('is-loading');
    $('#terrain-status').textContent = simulationOn ? 'Symulowany przelot trwa' : 'Dron oczekuje na start symulacji';
    terrainScene.setActive(true);
  } catch (error) {
    terrainView.classList.remove('is-loading');
    terrainView.classList.add('load-error');
    $('#terrain-status').textContent = 'Widok 3D offline · korzystaj z mapy 2D';
  }
}

function animateIncidentArrival() {
  const card = $('#incident-card');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  card.classList.remove('state-arrived');
  requestAnimationFrame(() => {
    card.classList.add('state-arrived');
    card.addEventListener('animationend', () => card.classList.remove('state-arrived'), { once: true });
  });
}

function updateRole(role) {
  currentRole = role;
  $('#role-screen').classList.add('hidden');
  $('#workspace').classList.remove('hidden');
  panel.dataset.role = role;
  roleTabs.forEach((tab) => {
    const selected = tab.dataset.role === role;
    tab.classList.toggle('active', selected);
    if (tab.hasAttribute('aria-pressed')) tab.setAttribute('aria-pressed', String(selected));
  });
  const titles = {
    commander: ['Obraz sytuacji', 'Sprawdź nowe zgłoszenia i zdecyduj o dalszym działaniu.'],
    operator: ['Lot drona', 'Prowadź symulację i przekaż zauważone zdarzenie.'],
    ground: ['Informacje dla jednostki', 'Sprawdź ostrzeżenia i zalecane działanie na trasie.'],
  };
  $('#panel-title').textContent = titles[role][0];
  $('#panel-description').textContent = titles[role][1];
  $('#operator-banner').classList.toggle('hidden', !(role === 'operator' && airspaceRestricted));
  $('#operator-actions').classList.toggle('hidden', role !== 'operator');
  $('#start-simulation')?.classList.toggle('hidden', role !== 'operator');
  renderIncident();
}

function addTimelineEvent(text) {
  demoClock += 1;
  const minute = 42 + Math.floor(demoClock / 60);
  const second = demoClock % 60;
  const time = `07:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`;
  timelineItems.unshift({ time, text, current: true });
  timelineItems = timelineItems.map((item, index) => ({ ...item, current: index === 0 }));
  renderTimeline();
}

function renderTimeline() {
  timeline.innerHTML = timelineItems.map((item) => `
    <div class="timeline-event${item.current ? ' current' : ''}">
      <span class="timeline-node"><i></i></span><time>${item.time}</time><p>${item.text}</p>
    </div>`).join('');
}

function renderIncident() {
  const exists = Boolean(incidentState);
  $('#incident-empty').classList.toggle('hidden', exists);
  $('#incident-card').classList.toggle('hidden', !exists);
  incidentMarker.classList.toggle('hidden', !exists || incidentState.status === 'REJECTED');
  map.classList.toggle('has-incident', exists && !['REJECTED', 'CLEARED'].includes(incidentState.status));
  $('#incident-counter').textContent = exists && incidentState.status !== 'CLEARED' && incidentState.status !== 'REJECTED' ? '1' : '0';
  const open = exists && !['CLEARED', 'REJECTED'].includes(incidentState.status);
  $('#incident-count').textContent = open ? '01' : '00';
  const attentionCopy = {
    REPORTED: 'Nowe zgłoszenie oczekuje na weryfikację',
    VERIFIED: 'Zgłoszenie potwierdzone. Przekaż alert zespołom.',
    ACTIVE: 'Aktywne ostrzeżenie dla zespołów',
  };
  $('#attention-label').textContent = open ? attentionCopy[incidentState.status] : 'Brak aktywnych alertów';
  $('#incident-status').textContent = incidentState?.statusLabel || 'ZGŁOSZONE';
  $('#incident-actions').classList.toggle('hidden', !exists || incidentState.status !== 'REPORTED' || currentRole !== 'commander');
  $('#activate-actions').classList.toggle('hidden', !exists || incidentState.status !== 'VERIFIED' || currentRole !== 'commander');
  $('#clear-actions').classList.toggle('hidden', !exists || incidentState.status !== 'ACTIVE' || currentRole !== 'commander');
  $('#incident-card').classList.toggle('is-active', incidentState?.status === 'ACTIVE');
  let reportButton = $('#operator-report');
  if (!reportButton) {
    reportButton = document.createElement('button');
    reportButton.id = 'operator-report';
    reportButton.className = 'operator-report-button';
    reportButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Zgłoś zdarzenie z obserwacji';
    reportButton.addEventListener('click', openReport);
    $('#operator-actions').append(reportButton);
  }
  reportButton.classList.toggle('hidden', currentRole !== 'operator' || (exists && incidentState.status !== 'CLEARED' && incidentState.status !== 'REJECTED'));
  let guidance = $('#ground-guidance');
  if (currentRole === 'ground' && exists && incidentState.status === 'ACTIVE') {
    if (!guidance) {
      guidance = document.createElement('div');
      guidance.id = 'ground-guidance';
      guidance.className = 'ground-guidance';
      $('#incident-card').append(guidance);
    }
    guidance.innerHTML = '<strong>ZALECENIE DLA ZESPOŁU</strong>Nie wjeżdżaj na drogę 14. Jedź objazdem przez most północny.';
  } else if (guidance) {
    guidance.remove();
  }
  const isGround = currentRole === 'ground';
  $('.incident-section .panel-section-title h2').textContent = isGround ? 'Alerty dla Twojej trasy' : 'Zdarzenia w sektorze';
  if (isGround && incidentState?.status === 'ACTIVE') {
    $('#incident-card h3').textContent = 'Droga 14 nieprzejezdna';
    $('#incident-card > p').textContent = incidentState.description;
    $('#incident-card .severity-tag').innerHTML = '<i></i>OMIŃ TEN ODCINEK';
  } else if (incidentState) {
    $('#incident-card h3').textContent = 'Droga całkowicie zablokowana';
    $('#incident-card > p').textContent = incidentState.description;
    $('#incident-card .severity-tag').innerHTML = `<i></i>${incidentState.severityLabel} PRIORYTET`;
  }
  $('#incident-card .incident-age').textContent = incidentState?.status === 'ACTIVE' ? 'POTWIERDZONE' : incidentState?.status === 'REJECTED' ? 'ODRZUCONE' : incidentState?.status === 'CLEARED' ? 'ZAMKNIĘTE' : 'TERAZ';
}

function openReport() {
  if (incidentState && !['CLEARED', 'REJECTED'].includes(incidentState.status)) {
    showToast('Zgłoszenie już oczekuje na obsługę.');
    return;
  }
  reportOpener = document.activeElement;
  $('#report-overlay').classList.remove('hidden');
  $('#event-description').focus();
}

function closeReport() {
  const wasOpen = !$('#report-overlay').classList.contains('hidden');
  $('#report-overlay').classList.add('hidden');
  if (wasOpen) {
    const target = reportOpener?.isConnected && !reportOpener.closest('.hidden') ? reportOpener : $('#operator-report');
    target?.focus();
    reportOpener = null;
  }
}

function setAirspace(restricted) {
  airspaceRestricted = restricted;
  document.body.classList.toggle('airspace-restricted', restricted);
  $('#airspace-label').textContent = restricted ? 'OGRANICZONA' : 'OTWARTA';
  $('#airspace-alert').classList.toggle('hidden', !restricted);
  $('#safety-control').innerHTML = restricted
    ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v5c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6l-8-3Z"/><path d="m8 12 3 3 5-6"/></svg><span>Przywróć status przestrzeni</span><svg class="safety-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>'
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v5c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6l-8-3Z"/><path d="M12 8v5m0 3h.01"/></svg><span>Symuluj ograniczenie przestrzeni</span><svg class="safety-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>';
  $('#operator-banner').classList.toggle('hidden', !(currentRole === 'operator' && restricted));
  if (restricted) {
    addTimelineEvent('Symulacja: wprowadzono ograniczenie przestrzeni');
    if (currentRole === 'operator') showToast('Przerwij misję zgodnie z procedurą operatora.');
  } else {
    addTimelineEvent('Przywrócono status przestrzeni');
  }
}

function startSimulation() {
  if (simulationOn) {
    clearInterval(simulationTimer);
    simulationOn = false;
    map.classList.remove('is-flying');
    if (mapViewMode === '3d') terrainScene?.setFlight(false);
    $('#terrain-status').textContent = 'Symulowany przelot wstrzymany';
    $('#start-simulation').innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 12 7-12 7V5Z"/></svg>Uruchom symulację drona';
    showToast('Symulacja lotu zatrzymana.');
    return;
  }
  simulationOn = true;
  map.classList.add('is-flying');
  if (mapViewMode === '3d') terrainScene?.setFlight(true);
  $('#start-simulation').innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h4v14H7zm6 0h4v14h-4z"/></svg>Zatrzymaj symulację';
  routeIndex = 0;
  addTimelineEvent('Dron 01 rozpoczął symulowany przelot');
  showToast('Symulacja lotu rozpoczęta.');
  simulationTimer = setInterval(() => {
    routeIndex = (routeIndex + 1) % route.length;
    const point = route[routeIndex];
    positionDrone(point);
    const battery = Math.max(62, 78 - Math.floor(routeIndex * 0.4));
    $('#battery').innerHTML = `${battery} <small>%</small>`;
    $('#altitude').innerHTML = `${81 + (routeIndex % 5)} <small>m</small>`;
    $('#speed').innerHTML = `${(7.9 + (routeIndex % 4) * 0.3).toFixed(1)} <small>m/s</small>`;
    $('#map-altitude').textContent = String(81 + (routeIndex % 5));
  }, 1200);
}

function resetDemo() {
  clearInterval(simulationTimer);
  clearInterval(telemetryTimer);
  simulationOn = false;
  map.classList.remove('is-flying', 'has-incident');
  terrainScene?.setFlight(false);
  setMapView('2d');
  setZoom(1);
  $('#terrain-status').textContent = 'Dron oczekuje na start symulacji';
  $('#start-simulation').innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 12 7-12 7V5Z"/></svg>Uruchom symulację drona';
  incidentState = null;
  routeIndex = 0;
  demoClock = 42;
  timelineItems = [...initialTimeline];
  positionDrone({ x: 31, y: 63 });
  $('#map-altitude').textContent = '82';
  $('#battery').innerHTML = '78 <small>%</small>';
  $('#altitude').innerHTML = '82 <small>m</small>';
  $('#speed').innerHTML = '8.4 <small>m/s</small>';
  setAirspace(false);
  timelineItems = [...initialTimeline];
  renderTimeline();
  $('#map-toast').classList.add('hidden');
  closeReport();
  updateRole('commander');
  showToast('Pokaz wrócił do stanu początkowego.');
}

roleTabs.forEach((tab) => tab.addEventListener('click', () => updateRole(tab.dataset.role)));
$$('.role-choice').forEach((choice) => choice.addEventListener('click', () => $('#panel-title').focus()));
$('#change-role').addEventListener('click', () => {
  $('#workspace').classList.add('hidden');
  $('#role-screen').classList.remove('hidden');
  $('.role-choice[data-role="' + currentRole + '"]')?.focus();
});
$('#prompt-report').addEventListener('click', () => { updateRole('operator'); openReport(); });
$('#close-report').addEventListener('click', closeReport);
$('#report-overlay').addEventListener('click', (event) => { if (event.target === $('#report-overlay')) closeReport(); });
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !$('#report-overlay').classList.contains('hidden')) {
    closeReport();
    return;
  }
  if (event.key !== 'Tab' || $('#report-overlay').classList.contains('hidden')) return;
  const focusable = [...$('#report-overlay').querySelectorAll('button, input, select, textarea, [href], [tabindex]:not([tabindex="-1"])')]
    .filter((element) => !element.disabled && !element.closest('.hidden'));
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
});
$('#report-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const descriptions = {
    blocked: 'Przewrócone drzewo blokuje przejazd do punktu ewakuacji przy drodze 14.',
    infrastructure: 'Widoczne uszkodzenie infrastruktury w pobliżu trasy dojazdu.',
    flood: 'Woda wdarła się na jezdnię i może uniemożliwić przejazd.',
    other: $('#event-description').value.trim() || 'Operator zgłosił zagrożenie wymagające sprawdzenia.',
  };
  const selectedSeverity = $('input[name="severity"]:checked').value;
  incidentState = {
    status: 'REPORTED', statusLabel: 'ZGŁOSZONE', description: descriptions[$('#event-type').value],
    severityLabel: { medium: 'ŚREDNI', high: 'WYSOKI', critical: 'KRYTYCZNY' }[selectedSeverity],
  };
  closeReport();
  addTimelineEvent('Operator drona zgłosił zablokowaną drogę');
  renderIncident();
  $('#map-toast').classList.remove('hidden');
  updateRole('commander');
  $('#verify-incident').focus();
  animateIncidentArrival();
  showToast('Zgłoszenie przekazano dowódcy do weryfikacji.');
});

$('#verify-incident').addEventListener('click', () => {
  if (!incidentState || incidentState.status !== 'REPORTED') return;
  incidentState.status = 'VERIFIED';
  incidentState.statusLabel = 'POTWIERDZONE';
  addTimelineEvent('Dowódca potwierdził zgłoszenie z drona');
  renderIncident();
  $('#activate-incident').focus();
  animateIncidentArrival();
  showToast('Zdarzenie potwierdzone. Możesz powiadomić zespoły.');
});

$('#activate-incident').addEventListener('click', () => {
  if (!incidentState || incidentState.status !== 'VERIFIED') return;
  incidentState.status = 'ACTIVE';
  incidentState.statusLabel = 'AKTYWNE';
  addTimelineEvent('Aktywne ostrzeżenie przekazano jednostce terenowej');
  renderIncident();
  $('.role-switch .role-tab[data-role="ground"]').focus();
  animateIncidentArrival();
  showToast('Jednostka terenowa otrzymała ostrzeżenie o blokadzie.');
});

function rejectIncident() {
  if (!incidentState) return;
  incidentState.status = 'REJECTED';
  incidentState.statusLabel = 'ODRZUCONE';
  addTimelineEvent('Zgłoszenie odrzucone przez dowódcę');
  renderIncident();
  $('#attention-label').focus();
  animateIncidentArrival();
  showToast('Zgłoszenie odrzucone. Nie przekazano alertu.');
}
$('#reject-incident').addEventListener('click', rejectIncident);
$('#reject-verified').addEventListener('click', rejectIncident);
$('#clear-incident').addEventListener('click', () => {
  if (!incidentState || incidentState.status !== 'ACTIVE') return;
  incidentState.status = 'CLEARED';
  incidentState.statusLabel = 'ZAMKNIĘTE';
  addTimelineEvent('Jednostka potwierdziła usunięcie przeszkody');
  renderIncident();
  $('#attention-label').focus();
  animateIncidentArrival();
  showToast('Zdarzenie zamknięte. Zespoły otrzymały aktualizację.');
});
$('#safety-control').addEventListener('click', () => setAirspace(!airspaceRestricted));
$('#ack-airspace').addEventListener('click', () => {
  $('#operator-banner').classList.add('hidden');
  $('#start-simulation').focus();
  showToast('Potwierdzono odbiór alertu przestrzeni.');
});
$('#reset-demo').addEventListener('click', resetDemo);
mapViewButtons.forEach((button) => button.addEventListener('click', () => setMapView(button.dataset.mapView)));
$('#map-zoom-in').addEventListener('click', () => setZoom(mapZoom + .15));
$('#map-zoom-out').addEventListener('click', () => setZoom(mapZoom - .15));
$('#map-reset-view').addEventListener('click', () => { setZoom(1); terrainScene?.resetView(); });
map.dataset.view = '2d';
positionDrone(route[0]);
if ('ResizeObserver' in window) new ResizeObserver(() => positionDrone(route[routeIndex])).observe(mapWorld);
else window.addEventListener('resize', () => positionDrone(route[routeIndex]));
$('#timeline-toggle').addEventListener('click', () => {
  const expanded = $('#timeline-toggle').getAttribute('aria-expanded') === 'true';
  $('#timeline-toggle').setAttribute('aria-expanded', String(!expanded));
  $('#timeline').classList.toggle('hidden', expanded);
  $('#timeline-toggle').textContent = expanded ? 'Pokaż historię' : 'Zwiń historię';
});

const startButton = document.createElement('button');
startButton.id = 'start-simulation';
startButton.className = 'operator-report-button simulation-button';
startButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 12 7-12 7V5Z"/></svg>Uruchom symulację drona';
startButton.addEventListener('click', startSimulation);
$('#operator-actions').append(startButton);

const reportButton = document.createElement('button');
reportButton.id = 'operator-report';
reportButton.className = 'operator-report-button hidden';
reportButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Zgłoś zdarzenie z obserwacji';
reportButton.addEventListener('click', openReport);
$('#operator-actions').append(reportButton);

// Telemetry has small, bounded variation so the demo reads as a live feed without claiming a real connection.
telemetryTimer = setInterval(() => {
  if (simulationOn) return;
  $('#speed').innerHTML = `${(8.2 + Math.random() * 0.5).toFixed(1)} <small>m/s</small>`;
}, 4200);

renderTimeline();
renderIncident();
